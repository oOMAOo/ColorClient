#define QT_FEATURE_qt3d_assimp 1

#define QT_FEATURE_qt3d_render 1

#define QT_FEATURE_qt3d_input 1

#define QT_FEATURE_qt3d_logic 1

#define QT_FEATURE_qt3d_extras 1

#define QT_FEATURE_qt3d_animation 1

